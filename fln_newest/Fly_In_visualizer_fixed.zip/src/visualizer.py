"""Small Arcade view of the Fly-In simulation."""

from __future__ import annotations

import arcade

from domain import Zone
from graph import Graph

WIDTH = 1000
HEIGHT = 700
MARGIN = 100
ZONE_RADIUS = 22
DRONE_RADIUS = 10
TURN_DELAY = 0.8

BACKGROUND = (15, 23, 42)
LINE_COLOR = (70, 90, 115)
TEXT_COLOR = (225, 232, 240)
DRONE_COLOR = (255, 255, 255)

COLORS = {
    "red": (239, 68, 68),
    "green": (34, 197, 94),
    "blue": (59, 130, 246),
    "yellow": (250, 204, 21),
    "orange": (249, 115, 22),
    "purple": (168, 85, 247),
    "gray": (107, 114, 128),
    "grey": (107, 114, 128),
    "cyan": (45, 212, 191),
}


class Visualizer(arcade.Window):
    """Display the map and move the drones through it."""

    def __init__(self, graph: Graph, log: list[str]) -> None:
        super().__init__(WIDTH, HEIGHT, "Fly-In - Drone Simulation")
        arcade.set_background_color(BACKGROUND)
        self.graph = graph
        self.log = log
        self.turn = 0
        self.timer = 0.0
        self.paused = False
        self.positions = self._start_positions()
        self.transit: dict[int, str] = {}
        self.active_connections: set[str] = set()
        self.view_scale, self.offset = self._layout()

    def _start_positions(self) -> dict[int, str]:
        """Put every drone at the start zone."""
        if self.graph.start is None:
            return {}
        return {
            drone_id: self.graph.start.name
            for drone_id in range(1, self._drone_count() + 1)
        }

    def _drone_count(self) -> int:
        """Get the number of drones from the simulation log."""
        highest = 0
        for line in self.log:
            for token in line.split():
                drone_id = int(token[1:].split("-", 1)[0])
                highest = max(highest, drone_id)
        return highest

    def _layout(self) -> tuple[float, tuple[float, float]]:
        """Scale and center the map inside the window."""
        zones = list(self.graph.zones.values())
        min_x = min(zone.x for zone in zones)
        max_x = max(zone.x for zone in zones)
        min_y = min(zone.y for zone in zones)
        max_y = max(zone.y for zone in zones)
        map_width = max(max_x - min_x, 1)
        map_height = max(max_y - min_y, 1)
        scale = min(
            (WIDTH - 2 * MARGIN) / map_width,
            (HEIGHT - 180) / map_height,
        )
        map_x = (WIDTH - map_width * scale) / 2
        map_y = 100 + (HEIGHT - 180 - map_height * scale) / 2
        return scale, (map_x - min_x * scale, map_y - min_y * scale)

    def _point(self, zone_name: str) -> tuple[float, float]:
        """Convert map coordinates to screen coordinates."""
        zone = self.graph.zones[zone_name]
        return (
            zone.x * self.view_scale + self.offset[0],
            zone.y * self.view_scale + self.offset[1],
        )

    def _advance(self) -> None:
        """Display the next simulation turn."""
        if self.turn >= len(self.log):
            return

        self.active_connections.clear()
        for token in self.log[self.turn].split():
            drone, target = token.split("-", 1)
            drone_id = int(drone[1:])
            if target in self.graph.zones:
                self.positions[drone_id] = target
                self.transit.pop(drone_id, None)
            else:
                self.transit[drone_id] = target
                self.active_connections.add(target)
        self.turn += 1

    def on_update(self, delta_time: float) -> None:
        """Advance one turn automatically."""
        if self.paused or self.turn >= len(self.log):
            return
        self.timer += delta_time
        if self.timer >= TURN_DELAY:
            self.timer = 0.0
            self._advance()

    def on_key_press(self, key: int, modifiers: int) -> None:
        """Pause, resume, or manually move through the simulation."""
        if key == arcade.key.SPACE:
            self.paused = not self.paused
        elif key == arcade.key.RIGHT:
            self.paused = True
            self._advance()
        elif key == arcade.key.LEFT:
            self.paused = True
            self._reset()
            for _ in range(max(self.turn - 1, 0)):
                self._advance()

    def _reset(self) -> None:
        """Return the visualization to turn zero."""
        self.turn = 0
        self.timer = 0.0
        self.positions = self._start_positions()
        self.transit.clear()
        self.active_connections.clear()

    def on_draw(self) -> None:
        """Draw the map, drones, and simple status bar."""
        self.clear()
        self._draw_header()
        self._draw_connections()
        self._draw_zones()
        self._draw_drones()
        self._draw_footer()

    def _draw_header(self) -> None:
        """Draw the title and current turn."""
        arcade.draw_text(
            "FLY-IN",
            35,
            HEIGHT - 42,
            TEXT_COLOR,
            22,
            bold=True,
        )
        status = "PAUSED" if self.paused else "RUNNING"
        arcade.draw_text(
            f"Turn {self.turn} / {len(self.log)}   {status}",
            WIDTH - 280,
            HEIGHT - 40,
            TEXT_COLOR,
            14,
        )

    def _draw_connections(self) -> None:
        """Draw all network connections."""
        for connection in self.graph.connections:
            start = self._point(connection.zone_a.name)
            end = self._point(connection.zone_b.name)
            color = (
                (120, 210, 255)
                if connection.name in self.active_connections
                else LINE_COLOR
            )
            width = 4 if connection.name in self.active_connections else 2
            arcade.draw_line(*start, *end, color, width)

    def _draw_zones(self) -> None:
        """Draw zones with their names and types."""
        for zone in self.graph.zones.values():
            x, y = self._point(zone.name)
            color = self._zone_color(zone)
            arcade.draw_circle_filled(x, y, ZONE_RADIUS, color)
            arcade.draw_circle_outline(x, y, ZONE_RADIUS + 2, TEXT_COLOR, 2)
            arcade.draw_text(
                zone.name,
                x,
                y - ZONE_RADIUS - 20,
                TEXT_COLOR,
                11,
                anchor_x="center",
            )

    def _draw_drones(self) -> None:
        """Draw drones at zones or in the middle of restricted links."""
        groups: dict[str, list[int]] = {}
        for drone_id, zone_name in self.positions.items():
            groups.setdefault(zone_name, []).append(drone_id)

        for zone_name, drone_ids in groups.items():
            for index, drone_id in enumerate(drone_ids):
                if drone_id in self.transit:
                    x, y = self._transit_point(self.transit[drone_id])
                else:
                    x, y = self._drone_point(
                        zone_name, index, len(drone_ids)
                    )
                arcade.draw_circle_filled(x, y, DRONE_RADIUS, DRONE_COLOR)
                arcade.draw_circle_outline(
                    x, y, DRONE_RADIUS + 2, BACKGROUND, 2
                )
                arcade.draw_text(
                    f"D{drone_id}",
                    x,
                    y - 4,
                    BACKGROUND,
                    8,
                    anchor_x="center",
                )

    def _drone_point(
        self, zone_name: str, index: int, count: int
    ) -> tuple[float, float]:
        """Separate drones that share a zone."""
        x, y = self._point(zone_name)
        if count == 1:
            return x, y
        shift = (index - (count - 1) / 2) * 22
        return x + shift, y + 28

    def _transit_point(self, connection_name: str) -> tuple[float, float]:
        """Put a drone halfway along a restricted connection."""
        connection = next(
            item for item in self.graph.connections
            if item.name == connection_name
        )
        first = self._point(connection.zone_a.name)
        second = self._point(connection.zone_b.name)
        return (
            (first[0] + second[0]) / 2,
            (first[1] + second[1]) / 2,
        )

    @staticmethod
    def _zone_color(zone: Zone) -> tuple[int, int, int]:
        """Choose the display color for a zone."""
        if zone.is_start:
            return (45, 212, 191)
        if zone.is_end:
            return (250, 204, 21)
        if zone.color:
            return COLORS.get(zone.color.lower(), (156, 163, 175))
        colors = {
            "normal": (156, 163, 175),
            "priority": (34, 197, 94),
            "restricted": (168, 85, 247),
            "blocked": (75, 85, 100),
        }
        return colors[zone.zone_type]

    def _draw_footer(self) -> None:
        """Draw the small legend and controls."""
        legend = "Start   End   Normal   Priority   Restricted   Blocked"
        controls = "SPACE: pause   ←/→: step"
        arcade.draw_text(legend, 35, 35, TEXT_COLOR, 11)
        arcade.draw_text(
            controls,
            WIDTH - 220,
            35,
            TEXT_COLOR,
            10,
        )


def show_simulation(graph: Graph, log: list[str]) -> None:
    """Open the graphical simulation."""
    Visualizer(graph, log)
    arcade.run()
